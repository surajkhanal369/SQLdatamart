CREATE TABLE IF NOT EXISTS Country (
	country_id INTEGER AUTO_INCREMENT,
	name VARCHAR(50),
	code VARCHAR(3),
	PRIMARY KEY (country_id)
);

CREATE TABLE IF NOT EXISTS City (
    city_id INTEGER AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    country_id INTEGER,
    PRIMARY KEY (city_id),
    FOREIGN KEY (country_id) REFERENCES Country(country_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Address(
    address_id INTEGER AUTO_INCREMENT,
    city_id INTEGER,
    street VARCHAR(255),
    house_number VARCHAR(50),
    PRIMARY KEY (address_id),
    FOREIGN KEY (city_id) REFERENCES City(city_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Guest (
    guest_id INTEGER AUTO_INCREMENT,
    first_name VARCHAR(25),
    last_name VARCHAR(25),
    email VARCHAR(30),
    phone_number VARCHAR(20),
    password VARCHAR(255),
    payment_info VARCHAR(20),
    PRIMARY KEY (guest_id)
);

CREATE TABLE IF NOT EXISTS Host (
    host_id INTEGER AUTO_INCREMENT,
    first_name VARCHAR(25),
    last_name VARCHAR(25),
    email VARCHAR(30),
    phone_number VARCHAR(20),
    password VARCHAR(255),
    rating DECIMAL(2, 1),
    bank_details TEXT,
    description TEXT,
    PRIMARY KEY (host_id)
);

CREATE TABLE IF NOT EXISTS Property_category (
    property_category_id INTEGER AUTO_INCREMENT,
    name VARCHAR(255),
    description TEXT,
    PRIMARY KEY (property_category_id)
);

CREATE TABLE IF NOT EXISTS Property (
    property_id INTEGER AUTO_INCREMENT,
    name VARCHAR(255),
    description TEXT,
    host_id INTEGER,
    category_id INTEGER,
    address_id INTEGER,
    num_bedrooms INTEGER,
    accomodates INTEGER,
    is_available BOOLEAN,
    price DECIMAL(10, 2),
    PRIMARY KEY (property_id),
    FOREIGN KEY (host_id) REFERENCES Host(host_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (category_id) REFERENCES Property_category(property_category_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (address_id) REFERENCES Address(address_id) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE IF NOT EXISTS Images (
    images_id INTEGER AUTO_INCREMENT,
    image_path VARCHAR(255),
    property_id INTEGER,
    PRIMARY KEY (images_id),
    FOREIGN KEY (property_id) REFERENCES Property(property_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Rule (
    rule_id INTEGER AUTO_INCREMENT,
    description TEXT,
    PRIMARY KEY (rule_id)
);

CREATE TABLE IF NOT EXISTS Property_rules (
    property_rules_id INTEGER AUTO_INCREMENT,
    rule_id INTEGER,
    property_id INTEGER,
    PRIMARY KEY (property_rules_id),
    FOREIGN KEY (rule_id) REFERENCES Rule(rule_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (property_id) REFERENCES Property(property_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Amenity (
    amenity_id INTEGER AUTO_INCREMENT,
    name VARCHAR(255),
    PRIMARY KEY (amenity_id)
);
CREATE TABLE IF NOT EXISTS Property_amenities (
    property_amenities_id INTEGER AUTO_INCREMENT,
    property_id INTEGER,
    amenity_id INTEGER,
    PRIMARY KEY (property_amenities_id),
    FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (amenity_id) REFERENCES amenity(amenity_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Booking (
    booking_id INTEGER AUTO_INCREMENT,
    property_id INTEGER,
    guest_id INTEGER,
    check_in_date DATE,
    check_out_date DATE,
    cancel_date DATE,
    created DATETIME,
    modified DATETIME,
    status VARCHAR(50),
    PRIMARY KEY (booking_id),
    FOREIGN KEY (property_id) REFERENCES Property(property_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES Guest(guest_id) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE IF NOT EXISTS Reviews (
    reviews_id INTEGER AUTO_INCREMENT,
    property_id INTEGER,
    reviewer_id INTEGER,
    booking_id INTEGER,
    comment TEXT,
    rating DECIMAL(3, 2),
    created DATETIME,
    modified DATETIME,
    PRIMARY KEY (reviews_id),
    FOREIGN KEY (property_id) REFERENCES Property(property_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (reviewer_id) REFERENCES Guest(guest_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE IF NOT EXISTS Dispute (
    dispute_id INTEGER AUTO_INCREMENT,
    booking_id INTEGER,
    description TEXT,
    created DATETIME,
    modified DATETIME,
    status VARCHAR(50),
    complainant INTEGER,
    respondent INTEGER,
    PRIMARY KEY (dispute_id),
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (complainant) REFERENCES Guest(guest_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (respondent) REFERENCES Host(host_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Guest_favorite_property (
    guest_favorite_property_id INTEGER AUTO_INCREMENT,
    guest_id INTEGER,
    property_id INTEGER,
    PRIMARY KEY (guest_favorite_property_id),
    FOREIGN KEY (guest_id) REFERENCES Guest(guest_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (property_id) REFERENCES Property(property_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Transactions (
    transactions_id INTEGER AUTO_INCREMENT,
    receiver_id INTEGER,
    sender_id INTEGER,
    booking_id INTEGER,
    amount DECIMAL(10, 2),
    tax_amount DECIMAL(10, 2),
    transfer_date DATETIME,
    status VARCHAR(50),
    PRIMARY KEY (transactions_id),
    FOREIGN KEY (receiver_id) REFERENCES Guest(guest_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES Host(host_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Activity_category (
    activity_category_id INTEGER AUTO_INCREMENT,
    name VARCHAR(255),
    PRIMARY KEY (activity_category_id)
);

CREATE TABLE IF NOT EXISTS Activity (
    activity_id INTEGER AUTO_INCREMENT,
    activity_category_id INTEGER,
    title VARCHAR(255),
    description TEXT,
    cost_per_person DECIMAL(10, 2),
    duration VARCHAR(10),
    PRIMARY KEY (activity_id),
    FOREIGN KEY (activity_category_id) REFERENCES Activity_category(activity_category_id)
);

CREATE TABLE IF NOT EXISTS Host_activities (
    host_activities_id INTEGER AUTO_INCREMENT,
    activity_id INTEGER,
    host_id INTEGER,
    PRIMARY KEY (host_activities_id),
    FOREIGN KEY (activity_id) REFERENCES activity(activity_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (host_id) REFERENCES host(host_id) ON DELETE CASCADE ON UPDATE CASCADE
);